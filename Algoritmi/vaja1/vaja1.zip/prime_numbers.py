import image_calculations
import graphics

if __name__ == "__main__":
    image_calculations.calculate_miller_rabin_speed_based_on_parameter_s()
    image_calculations.miller_vs_naive_speed()
    graphics.create_graphics()
