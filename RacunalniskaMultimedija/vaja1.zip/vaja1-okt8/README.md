## Run command

python3 readBit.py primer/test.bmp fr 000000000000000011111111 111111110000000000000000
python3 readBit.py primer/test.bmp f 000000000000000011111111
