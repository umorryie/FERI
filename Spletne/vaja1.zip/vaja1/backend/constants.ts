export enum ErrorNames {
  VALIDATION_ERROR = "ValidationError",
}

export enum ErrorMessages {
  REQUEST_PARAMETER_VALIDATION = "Invalid request parameters",
}
