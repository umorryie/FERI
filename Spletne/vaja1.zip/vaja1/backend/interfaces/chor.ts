export interface UpdateChor {
  name?: string;
  until?: Date;
  done?: boolean;
  alert_before_hours?: number;
}
