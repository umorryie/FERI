export interface ErrorHandler {
  status: number;
  message: string;
  name?: string;
}
